## Introduction

IBM Cloud Pak&reg; for Security  can connect disparate data sources - to uncover hidden threats and make better risk-based decisions - while the data stays where it is. By using open standards and IBM innovations, Cloud Pak for Security can securely access IBM and third-party tools to search for threat indicators across any cloud or on-premises location. Connect your workflows with a unified interface so you can respond faster to security incidents. Use Cloud Pak for Security to orchestrate and automate your security response so that you can better prioritize your team's time.

## What's Inside this Cloud Pak

IBM Cloud Pak&reg; for Security includes the following applications.

- [IBM® Data Explorer](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/data-explorer/overview.html) - enables customers to do federated search and investigation across their hybrid, multi-cloud environment in a single interface and workflow.

- [IBM® Threat Intelligence Insights](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/threat-intelligence-insights/overview.html) - IBM® Security Threat Intelligence Insights is an application that delivers unique, actionable, and timely threat intelligence.

- [IBM® Security Case Management](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/gcm/gcm_app_intro.html) -  IBM® Security Case Management for IBM Cloud Pak for Security provides organizations with the ability to track, manage, and resolve cybersecurity incidents.

- [IBM® Security Risk Manager](https://www.ibm.com/docs/en/SSTDPP_1.10/datariskmanager/welcome.html) - IBM® Security Risk Manager for Cloud Pak for Security is an application that automatically collects, correlates, and contextualizes risk insights across the IT and security ecosystem of your organization.

- [IBM® Security Threat Investigator](https://www.ibm.com/docs/en/SSTDPP_1.10/investigator/investigator_intro.html) - IBM® Security Threat Investigator automatically analyzes and investigates cases to help you make more informed decisions. By showing potential threats and the assets that are impacted, Threat Investigator can help determine the criticality of exposure, how many systems are at risk, and the level of remediation effort that is required.
  
- [IBM® Detection and Response Center](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/drc/c_DRC_intro.html) - IBM®  Detection and Response Center provides an overview of your organization's security posture through the security use cases available from IBM QRadar and the Sigma community tools. IBM Security Threat Investigator uses these security use cases in its investigations.

 For more information see, [IBM Documentation](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/scp-core/overview.html).

## Prerequisites

Please refer to the `Preparing to install IBM Cloud Pak® for Security` section in the [IBM Documentation](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/security-pak/planning.html).

## Resources Required

Please refer to the `Planning` section in the [IBM Documentation](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/security-pak/planning.html).

## Storage

Please refer to the `Persistent Storage` section in the [IBM Documentation](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/security-pak/persistent_storage.html).

## Installing IBM Cloud Pak&reg; for Security

Please refer to the `Installation` section in the [IBM Documentation](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/security-pak/installation.html).

## Verifying the Installation

Please refer to the `Installation` section in the [IBM Documentation](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/security-pak/installation.html).

## Upgrading IBM Cloud Pak&reg; for Security

Please refer to the `Upgrading Cloud Pak for Security` section in the [IBM Documentation](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/security-pak/upgrading.html).

## Uninstalling IBM Cloud Pak&reg; for Security

Please refer to the `Uninstalling IBM Cloud Pak for Security` section in the [IBM Documentation](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/security-pak/uninstalling_cp4s.html).

## Configuration

Please refer to the `Configuration parameters` table for each type of install in the [IBM Documentation](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/security-pak/installation.html).

## Limitations

The IBM Cloud Pak&reg; for Security application can only run on amd64 architecture type.

## Red Hat OpenShift SecurityContextConstraints Requirements

The ibm-cp-security-operator supports running with the OpenShift Container Platform default restricted Security Context Constraints (SCCs).

For more information about the OpenShift Container Platform Security Context Constraints, see [Managing Security Context Constraints](https://docs.openshift.com/container-platform/4.6/authentication/managing-security-context-constraints.html).

Custom SecurityContextConstraints definition:

```yaml
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
apiVersion: security.openshift.io/v1
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: restricted denies access to all host features and requires pods to be run with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC and it is used by default for authenticated users.
  creationTimestamp: "2020-02-14T15:44:45Z"
  generation: 1
  name: restricted-scc
  resourceVersion: "6128"
  selfLink: /apis/security.openshift.io/v1/securitycontextconstraints/restricted
  uid: ecb8cca7-4f40-11ea-bd4f-16ad4167adef
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

## Documentation

Further guidance can be found in the [IBM Documentation](https://www.ibm.com/docs/en/SSTDPP_1.10).

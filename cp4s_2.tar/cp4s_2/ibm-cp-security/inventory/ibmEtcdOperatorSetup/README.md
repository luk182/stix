# ibmEtcdOperator Setup for OCP 4.6+

## Install Etcd operator through CP4S Case on OCP

The ETCD Operator will be deployed as part of the overall CP4S


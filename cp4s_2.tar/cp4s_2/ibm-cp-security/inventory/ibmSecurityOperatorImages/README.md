# IBM Security Operator Images

This inventory contains a list of operator images used to deploy IBM Cloud Pak for Security.

#!/bin/bash
#
#################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2018.  All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#################################################################
#
# Run this script to monitor custom resource processing
#
# This script takes one argument; namespace
#
# Example:
#     ./checkcr.sh [-n cp4s] [-all]
#
## set default if its not passed in the args
CS_NAMESPACE=ibm-common-services
kubernetesCLI="oc"
checkScale() {
  repl=$($kubernetesCLI get isccomponent authsvc -o jsonpath="{.spec.action.replicas}")
  if [ -z "$repl" ]; then
    repl=$(oc get iscinventory iscplatform -o jsonpath="{.spec.definitions.replicas}")
    if [ "X$repl" == "X" ]; then
      echo "ERROR: no iscinventory found"
      return
    fi
  fi
  ar=$($kubernetesCLI get deploy authsvc -o jsonpath="{.spec.replicas}")
  case X${ar} in
    X$repl) ;;
    X)
       echo "ERROR: authsvc process not found"
       ;;
    *) echo "ERROR: invalid number of authsvc replicas: $ar"
       ;; 
  esac
  return
}

checkSeq() {
    for seq in $($kubernetesCLI get iscsequence -n $NAMESPACE -o name 2>/dev/null|sed -e 's!^.*/!!')
    do
      oc get iscsequence -n $NAMESPACE $seq -o yaml > /tmp/checkseq.$$.yaml
      gen=$(grep '    generation: ' /tmp/checkseq.$$.yaml | sed -e 's/^.*: //' -e 's/"//g')
      guard=$($kubernetesCLI get -n $NAMESPACE iscguard $seq -o 'jsonpath={.spec.generation}' 2>/dev/null)
      ar="$(sed -e '1,/ ansibleResult:/d' /tmp/checkseq.$$.yaml)"
      if [ "X$ar" == "X" ]; then
        ar="$(sed -e '1,/ conditions:/d' /tmp/checkseq.$$.yaml)"
      fi

      status=$(echo "$ar" | grep ' reason: ' | head -1 | sed -e 's/^.*: //')
      time=$(echo "$ar" | grep ' lastTransitionTime: ' | head -1 | sed -e 's/^.*: //')
      message=$(echo "$ar" | sed -e '1,/ lastTransitionTime: /d' -e 's/    message: //' |\
            sed  -n '1,/    reason:/p' | sed -e '$d' | head -10)

      if [ "X$gen" == "X$guard" ]; then
        if [ $ALL -eq 1 ]; then
            echo "ISCSequence $seq completed at $time"
        fi
        continue
      fi

      if [ "X$status" == "X" ]; then
        echo "ISCSequence $seq is in the queue"
        continue
      fi

      case "X$status" in
        X)
          echo "ISCSequence $seq is in the queue"
          continue
          ;;
        XRunning)
          echo "ISCSequence $seq is running since $time"
          continue
          ;;
        XSuccessful)
          echo "ISCSequence $seq is waiting to be upgraded"
          continue
          ;;
        *)
          echo "ISCSequence $seq has status $status at $time: $message"
          continue
          ;;
      esac
    done
    return
}

checkGoCR() {
  for cr in $(oc get $1 -o name 2>/dev/null)
  do
    ar=$($kubernetesCLI get $cr -o yaml | sed -e '1,/status:/d')
    status=$(echo "$ar" | grep type: | head -1 | sed -e 's/^.*: //')
    message=$(echo "$ar" | grep message: | head -1 | sed -e 's/^.*: //')
    time=$(echo "$ar" | grep lastTransitionTime: | head -1 | sed -e 's/^.*: //')

    case "X$status" in
       X) echo "$cr is not yet processed"
          ;;
       XCompleted|XSuccessful)
          if [ $ALL -eq 1 ]; then
            echo "$cr has been completed at $time"
          fi
          ;;
        *) echo "$cr has status "$status" since $time"
          ;;
     esac

  done
}

checkCR() {
    crd="$1"
    for cr in $($kubernetesCLI get $crd -n $NAMESPACE -o name 2>/dev/null)
    do
       $kubernetesCLI get -n $NAMESPACE $cr -o yaml > /tmp/checkseq.$$.yaml
       ar="$(sed -e '1,/ ansibleResult:/d' /tmp/checkseq.$$.yaml)"
       if [ "X$ar" == "X" ]; then
         ar="$(sed -e '1,/ conditions:/d' /tmp/checkseq.$$.yaml)"
       fi
       status=$(echo "$ar" | grep ' reason: ' | head -1 | sed -e 's/^.*: //')
       time=$(echo "$ar" | grep ' lastTransitionTime: '  | head -1 | sed -e 's/^.*: //')
       message=$(echo "$ar" | sed -e '1,/ lastTransitionTime: /d' -e 's/    message: //' |\
            sed  -n '1,/    reason:/p' | sed -e '$d' | head -10)

      case "X$status" in
        X)
          echo "$cr is in the queue"
          continue
          ;;
        XRunning)
          echo "$cr is running since $time"
          continue
          ;;
        XSuccessful|XComplete|XCompleted|XCreateClientSuccessful)
          if [ $ALL -eq 1 ]; then
            echo "$cr has been completed at $time"
          fi
          continue
          ;;
        *)
          echo "$cr has status $status at $time: $message"
          continue
          ;;
      esac
    done
    return
}

checkCRMultiState() {
    crd="$1"
    rm -rf /tmp/report.$$.tsv | true
    touch /tmp/report.$$.tsv
    for cr in $(oc get $crd -n $NAMESPACE -o name 2>/dev/null)
    do
       $kubernetesCLI get -n $NAMESPACE $cr -o yaml > /tmp/checkcr.$$.yaml
       ar="$(sed -e '1,/ conditions:/d' /tmp/checkcr.$$.yaml)"
       type=$(echo "$ar"    | grep ' type: '                | head -1 | sed -e 's/^.*: //')
       status=$(echo "$ar"  | grep ' status: '              | head -1 | sed -e 's/^.*: //')
       time=$(echo "$ar"    | grep ' lastTransitionTime: '  | head -1 | sed -e 's/^.*: //' | tr -d '"')
       message=$(echo "$ar" | grep ' message: '             | head -1 | sed -e 's/^.*: //')

        echo -e "$cr\t$type\t$time\t$status\t$message" >> /tmp/report.$$.tsv
    done

    if [ $ALL -eq 0 ]; then
       cat /tmp/report.$$.tsv | grep -v "Completed" > /tmp/report_filtered.$$.tsv
       rm /tmp/report.$$.tsv
       mv /tmp/report_filtered.$$.tsv /tmp/report.$$.tsv
    fi

    report_len=$(cat /tmp/report.$$.tsv | wc -l | tr -d ' ')
    if [ "X$report_len" != "X0" ]; then
       echo "-------------------------------------------------------- ------------------ -------------------- -------------- ----------------------------" >> /tmp/report_text.$$.tsv
       echo "cr deployment last_transition_time status message" >> /tmp/report_text.$$.tsv
       echo "-------------------------------------------------------- ------------------ -------------------- -------------- ----------------------------" >> /tmp/report_text.$$.tsv
       cat /tmp/report.$$.tsv >> /tmp/report_text.$$.tsv
       echo "-------------------------------------------------------- ------------------ -------------------- -------------- ----------------------------" >> /tmp/report_text.$$.tsv
       cat /tmp/report_text.$$.tsv | column -t
    fi
    return
}

checkCS() {
  xtra="management-ingress"
  pods=$($kubernetesCLI get pod -n $CS_NAMESPACE --no-headers |grep -vE 'Running|Completed')
  if [ "X$pods" != "X" ]; then
    echo "ERROR: Some of $CS_NAMESPACE pods are in failed state:"
    echo "$pods"
  fi

  # check if necessary components are installed
  for app in auth-idp auth-pap\
             platform-api $xtra \
             oidcclient-watcher secret-watcher
  do
     pod=$($kubernetesCLI get pod -o name -n $CS_NAMESPACE -lapp=$app)
     if [ "X$pod" == "X" ]; then
         echo "ERROR: Foundational services application $app not installed or failed"
     fi
  done
}

checkOIDC() {
  checkCR "Client"
  secret=$($kubernetesCLI get secret ibm-isc-oidc-credentials -o name)
  if [ "X$secret" == "X" ]; then
    echo "ERROR: secret ibm-isc-oidc-credentials has not been created"
  else
    if [ $ALL -eq 1 ]; then
       echo "INFO: secret ibm-isc-oidc-credentials has been created"
    fi
  fi
}


set_namespace() {
  NAMESPACE="$1"
  ns=$($kubernetesCLI get namespace $NAMESPACE -o name 2>/dev/null)
  if [ "X$ns" == "X" ]; then
    echo "ERROR: Invalid namespace $NAMESPACE"
    exit 1
  fi
  oc project $NAMESPACE >/dev/null
}

NAMESPACE=$($kubernetesCLI project | sed -e 's/^[^"]*"//' -e 's/".*$//')
ALL=0

while true
do
  arg="$1"
  if [ "X$arg" == "X" ]; then
    break
  fi
  shift
  case "$arg" in
  -n)
    set_namespace "$1"
    shift
    ;;
  -cs_namespace)
    CS_NAMESPACE=$1
    shift
    ;;
  --all)
    ALL=1
    ;;
  *)
    echo "ERROR: Invalid argument $arg"
    echo "Usage: $0 [ -n <Namespace> ] [--all]"
    exit 1
    ;;
esac
done

checkScale
checkCS
checkOIDC

checkSeq

checkCRMultiState connector.connector.isc.ibm.com
checkGoCR isctrusts.isc.ibm.com
for crd in etcds.isc.ibm.com minios.isc.ibm.com elastics.isc.ibm.com appentitlements cases.isc.ibm.com pgconnection.isc.ibm.com rabbitmq.isc.ibm.com pginstance.isc.ibm.com
do 
  checkCR $crd
done
rm -f /tmp/checkseq.$$.yaml

# Check if there are pods in pending state
pending_pods="$($kubernetesCLI get pod -n $NAMESPACE --no-headers | grep -E 'Pending|ContainerCreating|Init')"
if [ "X$pending_pods" != "X" ]; then
  echo "The following pods are in pending state and should be in running state shortly:"
  echo "$pending_pods"
fi

# Check if there are pods in error state
failed_pods="$($kubernetesCLI get pod -n $NAMESPACE --no-headers | grep -E 'Error|Failed|Unknown|Evicted')"
if [ "X$failed_pods" != "X" ]; then
  echo "The following pods are in error state:"
  echo "$failed_pods"
fi

deployments=$($kubernetesCLI get deploy -n $NAMESPACE -o jsonpath='{range .items[*]}{.metadata.name} {.status.replicas} {.status.readyReplicas}{"\n"}'| awk '{ if ($2 != $3) print $1 ": expect " $2 " pods have uptodate " $3 }')
if [ "X$deployments" != "X" ]; then
  echo "Problems in deployments replicas:"
  echo "$deployments"
fi

couchdbcluster=$($kubernetesCLI get statefulset -n $NAMESPACE -lformation_id=default-couchdbcluster -o name 2> /dev/null)
if [ "X$couchdbcluster" == "X" ]; then
   echo "Error: couchdbcluster not created for some reason"
fi

redis=$($kubernetesCLI get statefulset -n $NAMESPACE -lformation_id=default-redis -o name 2> /dev/null)
if [ "X$redis" == "X" ]; then
   echo "Error: redis instance not created for some reason"
fi

pods=$($kubernetesCLI get statefulset -n $NAMESPACE -o jsonpath='{range .items[*]}{.metadata.name} {.status.replicas} {.status.readyReplicas}{"\n"}' | awk '{ if ($2 != $3) print $1 ": expect " $2 " pods, but have " $3 }')
if [ "X$pods" != "X" ]; then
  echo "Problems in statefulsets replicas:"
  echo "$pods"
fi

pvc=$($kubernetesCLI get pvc -n $NAMESPACE --no-headers | grep -Ev "Bound" | awk '{print $1, $2}')
if [ "X$pvc" != "X" ]; then
  echo "Problems in PVC:"
  echo "$pvc"
fi

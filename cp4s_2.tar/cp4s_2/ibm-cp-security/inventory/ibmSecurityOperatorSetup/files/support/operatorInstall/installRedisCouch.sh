#!/usr/bin/env bash

#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2020,2021. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************


action=""
operator_case=""
operator_name=""
repo=""
online_source=""
offline_source=""
channelName=""
inventory=""
oname_short=""
operator_group=""

# Parse CLI parameters
while [ "${1-}" != "" ]; do
    case $1 in
    # Supported parameters for install/uninstall of couch and redis operators
    --action)
        shift
        action="${1}"
        ;;
    --operatorCase)
        shift
        operator_case="${1}"
        ;;
    --operatorName)
        shift
        operator_name="${1}"
        ;;
    --repo)
        shift
        repo="${1}"
        ;;
    --installType)
        shift
        airgapInstall="${1}"
        ;;
    # Additional supported parameters for direct script invocation ONLY
    --debug)
        set -x
        ;;

    *)
        echo "Invalid Option ${1}" >&2
        exit 1
        ;;
    esac
    shift
done


function err_exit() {
    echo >&2 "[ERROR] $1"
    exit 1
}

function validate_file_exists() {
    local file=$1
    [[ ! -f ${file} ]] && { err_exit "${file} not found, exiting deployment."; }
}

function setVars() {
    
    #setting vars based on what operator is being installed
    if [ "$operator_name" == "Redis" ]; then
        online_source="ibm-operator-catalog"
        offline_source="ibm-cloud-databases-redis-operator-catalog"
        channelName="v1.2-eus"
        inventory="redisOperator"
        oname_short="redis"
    elif [ "$operator_name" == "CouchDB" ]; then
        online_source="certified-operators"
        offline_source="couchdb-operator-catalog"
        channelName="v1.4"
        inventory="couchdbOperatorSetup"
        oname_short="couch"
    else
        err_exit "Incorrect Operator Name."
    fi 
    
    #check if operator group exists, if not create
    curr_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    operator_group="${curr_dir}"/operator_group.yaml
    validate_file_exists "$operator_group"

}

function installRedisCouch(){ 
    
    #OLM Install
    if [[ $("${kubernetesCLI}" get og -n "${namespace}" -o=go-template --template='{{len .items}}' ) -gt 0 ]]; then
        echo "Found operator group"
        "${kubernetesCLI}" get og -n "${namespace}" -o yaml
    else
        if ! sed <"$operator_group" "s|REPLACE_NAMESPACE|${namespace}|g" | "${kubernetesCLI}" apply -n "${namespace}" -f - ;then
            err_exit "CP4S Operator Operator Group creation failed"
        else
            echo "CP4S Operator Group Created"
        fi
    fi
    
    
    #Online/Offline install
    if [ "X${airgapInstall}" != "X" ]; then
        reg="$repo"
        if ! cloudctl case launch --case "$operator_case" --inventory "$inventory" --namespace "${namespace}" --action installCatalog --args "--registry $reg" --tolerance 1; then     
          err_exit "${operator_name} Operator catalog install has failed"
        fi
        if ! cloudctl case launch --case "$operator_case" --inventory "$inventory" --namespace "${namespace}" --action installOperator --args "--catalogSource $offline_source --channelName $channelName" --tolerance 1; then 
          err_exit "${operator_name} Operator install has failed";
        fi
    else
        reg="$repo"
       if ! cloudctl case launch --case "$operator_case" --inventory "$inventory" --namespace "${namespace}" --action installOperator --args "--catalogSource $online_source --channelName $channelName" --tolerance 1; then 
          err_exit "${operator_name} Operator install has failed";
       fi
    fi
    
}

function uninstallRedisCouch() {

    ## uninstall catalog, uninstall operator
    cloudctl case launch --case $operator_case --inventory "$inventory" --namespace "${namespace}" --action uninstallCatalog --tolerance 1 
    if [ $? -ne 0 ]; then err_exit "${operator_name} Operator Catalog uninstall has failed";fi
    cloudctl case launch --case $operator_case --inventory "$inventory" --namespace "${namespace}" --action uninstallOperator --tolerance 1 
    if [ $? -ne 0 ]; then err_exit "${operator_name} Operator uninstall has failed";fi
    
    ### remove serviceaccount
    "${kubernetesCLI}" get serviceaccount | grep "$oname_short" | awk '{print $1}'| xargs "${kubernetesCLI}" delete serviceaccount -n "${namespace}"
    ### remove deploy
    "${kubernetesCLI}" get deploy -n "${namespace}" --no-headers | awk '{print $1}' | grep "$oname_short" | xargs "${kubernetesCLI}" delete deploy -n "${namespace}"
    ### delete key
    if [ "$operator_name" == "Redis" ]; then
        "${kubernetesCLI}" delete secret ibm-entitlement-key -n "${namespace}" --ignore-not-found=true
    fi
    ## remove configmap
    "${kubernetesCLI}"  get cm -n "${namespace}" | grep "$oname_short" | awk '{print $1}' |  xargs "${kubernetesCLI}" delete cm -n "${namespace}"
    ## remove csv
    "${kubernetesCLI}"  get csv | grep "$oname_short" | awk '{print $1}' |  xargs "${kubernetesCLI}" delete csv -n "${namespace}"
    ## remove install plan
    "${kubernetesCLI}" get installplan | grep "$oname_short" | awk '{print $1}' | xargs "${kubernetesCLI}" delete installplan -n "${namespace}"
    "${kubernetesCLI}" delete og cp4s-operator-group --ignore-not-found=true -n "${namespace}"
}


setVars

if [ "$action" == "install" ]; then
    installRedisCouch
elif [ "$action" == "uninstall" ]; then
    uninstallRedisCouch
else
    err_exit "Invalid Operator install action."
fi

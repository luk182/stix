#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2021. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************
kubernetesCLI=oc
fs_namespace=""
cp4s_namespace=""
delete_ns="false"
del_crd="false"
del_cr="false"
uninstall_cp4s="false"
read_cr=""
force="false"
action=""
read_cr=""
read_crd=""
airgap=""
inputcase_dir=""

usage() {
    echo "
Please pass one of the following arguments:
    #### Uninstall CP4S
    --cp4sNamespace <CP4S-NS>         [mandatory option, if no flags are passed along with '--cp4sNamespace <CP4S-NS>' this initiates a complete cleanup of CP4S and terminates the namespace]
    --deleteCr                        [if this flag is set, it will ONLY uninstall a CP4S CR (e.g '--deleteCr <CR-NAME>'). If no option is provded it deletes 'all' the CP4S CRs]
    --deleteCrd                       [if this flag is set, this option will delete all the CP4S CRDs]
    --force                           [if this flag is set, this option will force delete all the remaining objects from a previous uninstall and terminate namespace]
    
    #### Uninstall Foundational Services
    --inputcase_dir <inputcase_dir> [ this is the path to downloaded case] 
    --uninstallFoundationalServices <namespace> [This option runs a complete cleanup of Foundational Services and terminates the namespace. <namespace> is optional, it takes a namespace where foundational Services are installed (default: ibm-common-services)]

    "
} 
####################################################################
#check if ns was provided in arguments list
function ns_provided()
{ 
  function check_ns_exist()
  {
    r=$($kubernetesCLI get project $@ 2>/dev/null)
    if [[ -z $r ]]; then
      usage
      exit 77
    else 
      $kubernetesCLI project $@
    fi
  }
  ##cp4s_namespace
  message='[ERROR] Namespace not provided'
  if [[ $@ == 'cp4s' ]];then
    if [[ -z $cp4s_namespace ]];then
      echo $message
      usage
      exit 77
    else
      check_ns_exist $cp4s_namespace 
    fi
  fi

  ##fs_namespace
  if [[ $@ == 'uninstall_foundational_services' ]];then
    if [[ -z $fs_namespace ]];then
      echo $message
      usage
      exit 1
    else 
      check_ns_exist $fs_namespace 
    fi
  fi
}

####################################################################
## function to remove imagecontent source policy required for Airgap
function delete_sourcepolicy()
{
  if [[ $airgap == 'true' ]]; then
    echo "-------------Deleting image contentsourcepolicy-------------"
    $kubernetesCLI delete imagecontentsourcepolicy ibm-cp-security --ignore-not-found=true
  fi
}


####################################################################
#cleanup catalog sourcecatalogsource
function cleanup_catalogsource()
{
  echo "-------------Uninstalling $@ catalogSources-------------"
  catalog_source_name=$@
  $kubernetesCLI delete catalogsource $catalog_source_name -n openshift-marketplace --ignore-not-found=true 2>/dev/null
  if [[ $force == 'true' ]];then
    $kubernetesCLI patch catalogsource $catalog_source_name -n openshift-marketplace --ignore-not-found=true --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
  fi
}
####################################################################
#terminate_ns
function terminate_ns()
{
  ns=$@
  get_ns()
  {
    $kubernetesCLI get namespace $ns -o name
  }
  if [[ "X$(get_ns $ns)" != "X" ]];then 
    echo  "-------------Deleting namespace $ns-------------"
    $kubernetesCLI delete ns $ns --wait=false --ignore-not-found 
  
    retry=30
    until [ "X$(get_ns $ns)" == "X" ]
    do
      retry=$((retry-1))
      echo "[INFO] Waiting for namespace $ns to terminate... (Remaining checks - $retry/30)"
      sleep 10
      if [ $retry == 0 ];then
        echo "[ERROR] Namespace: $ns did not terminate successfully"
        exit 1
      fi
    done
    echo "[SUCCESS] Namespace: $ns terminated successfully"
  fi
}

#####################################################################
#remove finalisers
function remove_finaliser()
{
  ns=$1
  obj_type=$2
  get_obj=($($kubernetesCLI get $obj_type -o name -n $ns --ignore-not-found))
  
  if [[ $obj_type == 'pods' ]]; then 
    $kubernetesCLI get pod --no-headers | awk '{print $1}' | xargs $kubernetesCLI delete pod --force --grace-period=0 >/dev/null
  fi
  
  
  if [ -z $get_obj ] ; then
    echo "* No $obj_type to patch "
  else
    for c in ${get_obj[@]}
    do
      $kubernetesCLI delete $c -n $ns --wait=false 2>/dev/null
      $kubernetesCLI patch $c -n $ns --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
    done
  fi
}

####################################################################
#delete pvc, sa, csv, sub etc
function deleteObject()
{ 
    ns=$1
    object_type=$2
    echo "-------------Deleting $object_type from $ns namespace-------------"
    pending_objs=($($kubernetesCLI get $object_type -n $ns -o name 2>/dev/null))
    if [[ ! -z $pending_objs ]];then
      $kubernetesCLI delete $object_type -n $ns --all --wait=false --ignore-not-found
    else 
      echo "[INFO] No $object_type found "
    fi  
}

####################################################################
#cert manager
function remove_certmanager()
{
    echo "-------------Deleting Certmanagers from $cp4s_namespace namespace-------------"
    #remove certmanagers
    cm_default=($($kubernetesCLI get certmanagers default))
    if [[ -z $cm_default ]]; then
      echo "[INFO] Default certmanager not found"
      else
      $kubernetesCLI delete certmanagers default --wait=false --ignore-not-found
      $kubernetesCLI patch certmanagers default --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
    fi
    $kubernetesCLI delete validatingwebhookconfiguration cert-manager-webhook 2>/dev/null
}

####################################################################
#delete operand request - Add patch before 
function del_operandreqregistry()
{
    echo "-------------Deleting operand requests from $cp4s_namespace namespace-------------"
    #del operand requests
    $kubernetesCLI delete operandrequest $@ --wait=false --ignore-not-found
    $kubernetesCLI patch operandrequest $@ --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null

    echo "-------------Deleting operand registry from $cp4s_namespace namespace-------------"
    $kubernetesCLI delete operandregistry $@ --wait=false --ignore-not-found
    $kubernetesCLI patch operandregistry $@ --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
    
}

####################################################################
#delete CRs
function cleanup_status_check()
{
    retry=40
    until [[ $retry == 0 ]]
    do 
      retry=$((retry-1))
      echo "[INFO] Waiting for cleanup to complete... (Remaining checks - $retry/40)"
      sleep 15
      $kubernetesCLI get pods -n $cp4s_namespace --no-headers | grep 'Terminating' >/dev/null
      if [[ $? == 1 ]];then
        echo "[SUCCESS] Cleanup finished successfully"
        break
      fi
      if [[ $retry == 0 ]];then
        echo "[Error] Timed out: waiting for cleanup to finish"
        break
      fi
    done
    
}
delete_cp4s_crs()
{
  set_crd_name1=$1
  cr_name1=$2

  $kubernetesCLI delete $set_crd_name1 $cr_name1 -n $cp4s_namespace --wait=false --ignore-not-found
  if [[ $force == 'true' ]];then
    $kubernetesCLI patch $set_crd_name1 $cr_name1 -n $cp4s_namespace --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
  fi
  
}
function run_delete_cp4s_crs()
{  
    ns_provided cp4s
    set_crd_name=''
    if [[ $@ == 'all' ]];then
       echo "-------------Uninstalling $@ CRs from $cp4s_namespace namespace-------------"
        crd=$($kubernetesCLI get crd --no-headers | awk '{print $1}'| grep isc.ibm.com)
        
        for crds in ${crd[*]}
        do 
            cr_name=($($kubernetesCLI get $crds -n $cp4s_namespace --no-headers --ignore-not-found | awk '{print $1}'))
            if [[ ! -z $cr_name ]];then
                for i in ${cr_name[*]}
                do
                  delete_cp4s_crs $crds $i
                done
            else 
                echo "[INFO] No CR found belonging to $crds"
            fi
        done
    else
        if [[ $@ == 'threatmgmt' ]];then
          set_crd_name='cp4sthreatmanagements.isc.ibm.com'
        else
          set_crd_name=$($kubernetesCLI get crd --no-headers --ignore-not-found | grep isc.ibm.com | awk '{print $1}' | grep $@)
          if [[ -z $set_crd_name ]];then echo "[ERROR] Check CR name"; exit 1; fi
        fi

        echo "-------------Uninstalling $@ CR from $cp4s_namespace namespace-------------"
        delete_cp4s_crs $set_crd_name $@
        sleep 90
        cleanup_status_check
        
    fi

    
}
function clean_knativeResources()
{
  this_object=$1
  this_ns=$2
  $kubernetesCLI get project $this_ns &>/dev/null
  if [[ $? -eq 0 ]]; then
    $kubernetesCLI delete $this_object -n $this_ns --ignore-not-found --wait=false 2>/dev/null 
    $kubernetesCLI patch $this_object -n $this_ns --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null 
  fi
}
#Uninstall Knative Resources
function uninstall_knative()
{
  echo "-------------Uninstalling cp4s-sandbox resources and terminating the namespace-------------"

  ###cp4s-sandbox
  clean_knativeResources route.serving.knative.dev/isc-cases-python3-scripting-service cp4s-sandbox
  clean_knativeResources route.serving.knative.dev/isc-cases-python3-scripting-service-cp4s cp4s-sandbox
  clean_knativeResources ingresses.networking.internal.knative.dev/isc-cases-python3-scripting-service cp4s-sandbox 
  clean_knativeResources ingresses.networking.internal.knative.dev/isc-cases-python3-scripting-service-cp4s cp4s-sandbox 
  terminate_ns cp4s-sandbox

}
####################################################################
#delete CRDs
function delete_crds()
{
  $kubernetesCLI delete crd $@ --ignore-not-found --wait=false
  if [[ $force == 'true' ]];then
    $kubernetesCLI patch crd $@ -n $cp4s_namespace --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
  fi
}
function run_delete_crds()
{
    ##########################  Deleting CRDS ##########################
    if [[ $del_crd == 'true' ]];then  
       echo "------------Remove CRD set to $del_crd------------"
       echo "[INFO] Removing CP4S CRD : $@"

      if [[ $@ == 'all' ]];then 
          cp4s_crds=($($kubernetesCLI get crd --no-headers --ignore-not-found | grep -E '.isc.ibm.com|getambassador.io' | awk '{print $1}'))
          for crds1 in ${cp4s_crds[@]}; 
          do 
            delete_crds $crds1
          done
          if [[ -z $cp4s_crds ]];then 
             echo "No CRDs found"
          fi
              #uninstall Knative resources as this will now be created by customers and we should not delete it. 
              uninstall_knative
          
      else
          $kubernetesCLI get crd --no-headers | grep $@ >/dev/null
          if [[ $? -ne 0 ]];then echo "[ERROR] CRD $@ not found"; exit 1; fi
          delete_crds $@
          
      fi
    
    fi
      #delete cp4s catalogsource from -n openshift-marketplace
      if [[ $airgap == 'true' ]]; then 
        echo "[INFO] Flag --airgap set to $airgap"
        #delete source policy
        delete_sourcepolicy

        #delete catalogsource
        cleanup_catalogsource cp4s
      fi

}

####################################################################
#uninstall CP4S
uninstall_cp4s()
{   
    #delete CRs
    run_delete_cp4s_crs threatmgmt
    run_delete_cp4s_crs all
    #delete objects
    deleteObject $cp4s_namespace csv
    deleteObject $cp4s_namespace subscription
    deleteObject $cp4s_namespace installplan
    deleteObject $cp4s_namespace serviceaccount
    deleteObject $cp4s_namespace deployment
    deleteObject $cp4s_namespace replicaset
    deleteObject $cp4s_namespace service
    deleteObject $cp4s_namespace pods
    deleteObject $cp4s_namespace pvc

    #remove certmanager
    remove_certmanager
    
    #del operand registry and requests
    del_operandreqregistry cp4s-threatmgmt
    del_operandreqregistry cp4s-foundations
    
    
    #force cleanup
    if [[ $force == 'true' ]];then 
        remove_finaliser $cp4s_namespace sa
        remove_finaliser $cp4s_namespace csv
        remove_finaliser $cp4s_namespace sub
        remove_finaliser $cp4s_namespace installplan
        remove_finaliser $cp4s_namespace deployment
        remove_finaliser $cp4s_namespace replicaset
        remove_finaliser $cp4s_namespace service
        remove_finaliser $cp4s_namespace pods
        remove_finaliser $cp4s_namespace pvc
        deleteObject $cp4s_namespace job
    fi
    
    list_of_rolebindings=(rolebinding.authorization.openshift.io/admin rolebindings.rbac.authorization.k8s.io/admin-dedicated-admins rolebindings.rbac.authorization.k8s.io/admin-system:serviceaccounts:dedicated-admin)
    for role in ${list_of_rolebindings[@]};
    do
        $kubernetesCLI patch $role -n $cp4s_namespace --type="json" -p '[{"op": "remove", "path":"/metadata/finalizers"}]' 2>/dev/null
        $kubernetesCLI delete $role -n $cp4s_namespace --ignore-not-found=true
    done
    
    #remove pending objects
    list_of_objects=(offerings.entitlements.extensions.platform.cp4s minio.isc pgprocedures.isc appentitlements.entitlements.extensions.platform.cp4s clients.oidc.security operandrequests.operator rolebindings namespacescopes.operator clients.oidc.security)
    for o in ${list_of_objects[@]}; 
    do  
        for p in $($kubernetesCLI get $o.ibm.com -o name --ignore-not-found)
        do
            #$kubernetesCLI get $p -n $cp4s_namespace --ignore-not-found 2>/dev/null
            $kubernetesCLI delete $p -n $cp4s_namespace --wait=false --ignore-not-found 2>/dev/null
            if [[ $force == 'true' ]];then 
                $kubernetesCLI patch $p -n $cp4s_namespace --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
            fi
        done
    done

    #delete cp4s catalogsource from -n openshift-marketplace
    if [[ $airgap == 'true' ]]; then 
      echo "[INFO] Flag --airgap set to $airgap"
      #delete source policy
      delete_sourcepolicy

      #delete catalogsource
      cleanup_catalogsource cp4s
    fi

    #terminate namespace
    terminate_ns $cp4s_namespace

}

####################################################################
#uninstall Foundational Services
function err_exit() 
{
    echo >&2 "[ERROR] $1"	
    exit 1	
}
function uninstall_foundational_services()
{   
   
    ns_provided uninstall_foundational_services

    if [[ -z ${inputcase_dir} ]];then echo "[ERROR] Case directory not found"; exit 1; fi
    

    echo "[WARNING] uninstalling CloudPak Foundational Services will delete CP4S dependencies. It is ideal to uninstall CP4S first before running this action."
    echo "Starting uninstall in 5 seconds, press CTRL+C if you wish to discontinue."
    sleep 5
    echo "-------------Uninstalling Common Services-------------"
    local caseName="ibm-cp-common-services"
    caseFound=$(ls "${inputcase_dir}"/${caseName}-*.tgz)
    if [[ ${caseFound} == *"no matches found"* ]]; then
        err_exit "CASE named ${caseName} not found."
    else
        echo "[INFO] Found CASE folder for ${caseName}: ${caseFound}"
    fi
    local inventoryOfOperator="ibmCommonServiceOperatorSetup"
   
    if [[ "$airgap" != "true" ]] || [[ "X$uninstall_method" == "Xcatalog" ]]; then
        url="$repo"
    else
        url="icr.io"
    fi

    if ! cloudctl case launch --case "${caseFound}" --namespace "${fs_namespace}" --inventory "$inventoryOfOperator" --action uninstall-catalog --args "--registry $url" --tolerance 1; then 
      err_exit "Failed to uninstall  CloudPak Foundational Services catalog"
    fi

    if ! cloudctl case launch --case "${caseFound}" --namespace "${fs_namespace}" --inventory "$inventoryOfOperator" --action  uninstall-operator --tolerance 1; then 
      err_exit "Failed to uninstall  CloudPak Foundational Services operator"
    fi
}

####################################################################
#execute actions as per flags
function execute_actions()
{  
    if [[ $force == 'true' ]];then
     echo "[INFO] Force cleanup is enabled"
    fi
    if [[ $del_cr == 'true' ]];then
        run_delete_cp4s_crs $read_cr
    elif [[ $del_crd == 'true' ]];then
        run_delete_crds $read_crd
    elif [[ $uninstall_cp4s == 'true' ]];then
        uninstall_cp4s
    fi
}

####################################################################
#function to store flags
function read_flags()
{   
    if [[ $@ == '' ]];then 
      echo "[ERROR] Incorrect way of passing arguments!"
      usage
      exit 77
    elif [[ $@ == 'delete_crd' ]];then
        del_crd='true'
    elif [[ $@ == 'delete_cr' ]];then 
        del_cr='true'
    elif [[ $@ == 'uninstall_cp4s' ]];then 
        uninstall_cp4s='true'
    fi  
}

####################################################################
#read input from user
while true
do
  flag="$1"
  shift
  if [ -z "$flag" ]; then
    break
  fi
    case $flag in
        --cp4sNamespace) 
            cp4s_namespace=$1
            read_flags uninstall_cp4s
            shift
            ;;
        --inputcase_dir)
            inputcase_dir=$1
            shift
            ;;
        --uninstallFoundationalServices) 
            fs_namespace=$1
            if [[ -z $fs_namespace ]];then fs_namespace='ibm-common-services';fi
            uninstall_foundational_services
            shift
            ;;
        --deleteCr)
            read_cr=$1
            if [[ -z $read_cr ]] || [[ $read_cr == '--force' ]]; then read_cr='all'; fi
            read_flags delete_cr
            shift
            ;;
        --deleteCrd)
            read_crd=$1
            if [[ -z $read_crd ]] || [[ $read_crd == '--force' ]] || [[ $read_crd == '--airgap' ]]; then 
              if [[ $read_crd == '--airgap' ]];then 
                airgap=true
              fi
              if [[ $read_crd == '--force' ]];then 
                force=true
              fi
              read_crd='all'
            fi
            read_flags delete_crd
            shift
            ;;
        --airgap)
            airgap='true'
            shift
            ;;
        --force)
            force='true'
            shift
            ;;
        *)
        echo "Invalid flag $flag"
        usage
        exit 77
        ;;
    esac
done
#call execute actions 
execute_actions

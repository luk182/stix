#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2021. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
caseLocation=$(echo ${scriptDir} | rev | cut -d'/' -f5- | rev)
docVersion=$(cat ${caseLocation}/case.yaml | grep "appVersion" | grep -Eo "[0-9]+([.][0-9]+)")
docLink="https://www.ibm.com/docs/en/SSTDPP_${docVersion}/docs/scp-core/authentication.html"
successfulText="[INFO] IBM Cloud Pak for Security deployment is complete. Visit the IBM Documentation $docLink and follow the next steps required to access your CP4S console:"
## This function returns the route of cp4s
function get_route() {

    ROUTE="$($kubernetesCLI get route isc-route-default --no-headers -n $namespace | awk '{print $2}')"

    echo "$ROUTE"
}
### This function checks the status of the threatmanagement cr and returns its status in
function check_threatmgmt_status() {
    ### Need to check the status of the top level CR after which we can optionally check the status of the operator crs

    ### Get the cr for top level ibm-cp-security

    CR=$($kubernetesCLI get cp4sthreatmanagements.isc.ibm.com -n $namespace -o name)

    [[ -z $CR ]] && {
        printf "IBM Cloud pak for Security Threat Management CR is not deployed,exiting \n"
        exit 1
    }

    THREAT_STATUS=$($kubernetesCLI get $CR -o jsonpath='{ range .items[*]}{.status.conditions[*].type}{"\n"}')

    # THREAT_STATUS_REASON=$($kubernetesCLI get $CR -o jsonpath='{ range .items[*]}{.status.conditions[*].reason}{"\n"}')

    if [[ $THREAT_STATUS != "Success" ]]; then

        maxRetry=100

        printf "%s\n" "[INFO] IBM Cloud Pak for Security deployment is $THREAT_STATUS"
        for ((retry = 0; retry <= maxRetry; retry++)); do
            TIME=$(date "+%Y/%m/%d-%H:%M:%S")
            THREAT_STATUS_MESSAGE=$($kubernetesCLI get $CR -o jsonpath='{ range .items[*]}{.status.conditions[*].message}{"\n"}')
            THREAT_STATUS=$($kubernetesCLI get $CR -o jsonpath='{ range .items[*]}{.status.conditions[*].type}{"\n"}')
            if [[ $THREAT_STATUS == "Success" ]]; then
                ### get the route here and display in the print statement
                cp4s_route=$(get_route)
                printf "\n---------------------------------------------------------------------\n"
                printf "%s\n" "$TIME: $successfulText $cp4s_route"
                break
            elif [[ "${THREAT_STATUS}" == "Degraded" ]]; then
                cp4s_route=$(get_route)
                printf "\n---------------------------------------------------------------------\n"
                printf "${TIME}:[WARN] IBM Cloud Pak for Security deployment is complete but SOAR Playbooks are not available.\n"
                printf "${TIME}:[INFO] Follow the instructions at https://www.ibm.com/docs/en/SSTDPP_${docVersion}/docs/security-pak/issue_knative_not_installed.html to resolve this issue.\n"
                printf "${TIME}:[INFO] Your CP4S console is available at ${cp4s_route}.\n"
                break
            else
                printf "\n------------------------------------------------------------\n"
                printf "%s\n" "$TIME:[INFO] $THREAT_STATUS_MESSAGE"
                printf "%s\n" "$TIME:[INFO] $THREAT_STATUS"
                sleep 30
            fi

            if [ ${retry} -eq ${maxRetry} ]; then
                printf "${TIME}:[ERROR] Timed out waiting for IBM Cloud Pak for Security deployment to complete"
                exit 1
            fi
        done
    else
        ### get the route here and display in the print statement
        cp4s_route=$(get_route)
        printf "%s\n" "$successfulText $cp4s_route"
    fi
}
function check_sequence() {
    LIST_OF_SUCCESSFUL_SEQUENCE=()
    LIST_OF_FAILED_SEQUENCE=()
    LIST_OF_PENDING_SEQUENCE=()

    SEQUENCE_LIST=$($kubernetesCLI get iscsequence -n "$namespace" --no-headers | awk '{print $1}' | sort)

    for SEQUENCE in ${SEQUENCE_LIST[*]}; do

        SEQUENCE_STATUS=$($kubernetesCLI get iscsequence "$SEQUENCE" -n "$namespace" 2>/dev/null | awk 'FNR == 2 {print $2}')
        ## If sequence is blank then it has not been processed

        if [[ "$SEQUENCE_STATUS" == "" ]]; then
            LIST_OF_PENDING_SEQUENCE+=("$SEQUENCE")

        elif [[ "X$SEQUENCE_STATUS" == "XFailed" ]]; then
            LIST_OF_FAILED_SEQUENCE+=("$SEQUENCE")

        elif [[ "X$SEQUENCE_STATUS" == "XSuccessful" ]]; then
            LIST_OF_SUCCESSFUL_SEQUENCE+=("$SEQUENCE")

        fi
    done

    ###
    if [[ -n ${LIST_OF_PENDING_SEQUENCE[*]} ]]; then

        printf "[INFO] The following sequence is yet to be processed:\n"
        printf "%s\n" "${LIST_OF_PENDING_SEQUENCE[*]}"
        printf "\n---------------------------------------------------------------------\n"
    fi
    if [[ -n ${LIST_OF_SUCCESSFUL_SEQUENCE[*]} ]] && [[ $DEBUG == "true" ]]; then

        printf "[INFO] The following sequence has completed:\n"
        printf "%s ${LIST_OF_SUCCESSFUL_SEQUENCE[*]}\n"
        printf "\n---------------------------------------------------------------------\n"
    fi
    if [[ -n ${LIST_OF_FAILED_SEQUENCE[*]} ]]; then
        printf "[INFO] The following sequence is currently in a failed state:\n"
        printf " %s ${LIST_OF_FAILED_SEQUENCE[*]}\n"
        printf "\n---------------------------------------------------------------------\n"
    fi

}

### Function will check the status of all the operators currently deployed
check_operators_cr() {
    CR_LIST=()
    CRD=$($kubernetesCLI get crd -n $namespace --no-headers | awk '{print $1}' | grep "isc.ibm.com" | grep "cp4s")

    for CRDS in ${CRD[*]}; do
        CR_NAME=$($kubernetesCLI get "$CRDS" -n "$namespace" -o name)
        ## we need to skip threat management cr here so we have already displayed it previously
        if [[ $CR_NAME != "cp4sthreatmanagement.isc.ibm.com/threatmgmt" ]]; then
            CR_LIST+=("$CR_NAME")
        fi
    done

    ## Loop through the CRs and get their status
    printf "%s\n" "Current status of Operator CRs"

    for CR in ${CR_LIST[*]}; do
        STATUS=$($kubernetesCLI get $CR -n $namespace -o jsonpath='{ range .items[*]}{.status.conditions[*].message}{"\n"}')

        printf "%s\n" "[INFO] Current status of $CR is $STATUS"
    done

    ## we need to figure out what cs namespace is set to so we can check it correctly

    CS=$($kubernetesCLI get cm cp4s-config -n $namespace -o jsonpath='{.data.CSNamespace}')

    bash "${scriptDir}"/checkcr.sh -n cp4s --all -cs_namespace "$CS"
}

check_threatmgmt_status
if [[ ${DEBUG} == "true" ]]; then
    check_operators_cr
    check_sequence
fi

# IBM Cloud Pak for Security Serviceability

This inventory allows users to deploy Serviceability.

# Introduction
IBM Cloud Pak® for Security can connect disparate data sources—to uncover hidden threats and make better risk-based decisions — while leaving the data where it resides. By using open standards and IBM innovations, IBM Cloud Pak® for Security can securely access IBM and third-party tools to search for threat indicators across any cloud or on-premises location. Connect your workflows with a unified interface so you can respond faster to security incidents. Use IBM Cloud Pak® for Security to orchestrate and automate your security response so that you can better prioritize your team's time.

## What's inside this Cloud Pak

Cloud Pak® for Security includes the following applications.
  
  - IBM® Threat Intelligence Insights is an application that delivers unique, actionable, and timely threat intelligence. The application provides most of the functions of IBM® X-Force® Exchange.
  - IBM® Security Data Explorer is a platform application that enables customers to do federated search and investigation across their hybrid, multi-cloud environment in a single interface and workflow.
  - IBM® Case Management for IBM Cloud Pak for Security provides organizations with the ability to track, manage, and resolve cybersecurity incidents.
  - IBM® Orchestration & Automation application is integrated on Cloud Pak for Security to provide most of the IBM Resilient Security Orchestration, Automation, and Response Platform feature set.
  - IBM® QRadar® Security Intelligence Platform is offered as an on-premises solution and delivers intelligent security analytics, enabling visibility, detection, and investigation for a wide range of known and unknown threats.
  - IBM® QRadar® Proxy 1.0 provides communication between IBM Cloud Pak for Security and IBM QRadar or QRadar on Cloud. This communication uses APIs to pull powerful QRadar data into the QRadar SIEM dashboards.
  - IBM® QRadar® User Behavior Analytics (UBA) is a tool for detecting insider threats in your organization. UBA, used in conjunction with the existing data in your QRadar system, can help you generate new insights around users and user risk. 
  - IBM® Security Risk Manager provides early visibility into potential security risks by correlating insights from multiple vectors so that you can prioritize risks to take appropriate remedial actions.
  - IBM® Threat Investigator is an application that automatically analyzes and investigates cases to help determine the criticality of exposure, how many systems are at risk, and the level of remediation effort that is required.
  - IBM® Detection and Response Center (Beta) provides an overview of your organization’s security posture through the security use cases available from IBM QRadar and the Sigma community tools. IBM® Threat Investigator uses these security use cases in its investigations.
  
 For more information, see [IBM Documentation](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/scp-core/overview.html).
 
# Prerequisites

## Red Hat OpenShift Container Platform

Please refer to the `Planning` section in the [IBM Documentation](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/security-pak/planning.html).

## Resource capacity requirements

| Node type | Number of nodes | CPU | RAM | Storage |
| --------- | ----------- | ----------- | ----------- | ----------- |
  Worker | 4 | 8 cores | 32 GB | 120 GB |

**Note:** The system disk requirements do not include the persistent storage requirements. The persistent storage requirement for IBM Cloud Pak® for Security is 3.5 TB. For more information, see [Persistent storage](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/security-pak/persistent_storage.html).

## Purchasing a license

Before you can install the Cloud Pak, you must purchase a license. Purchase a license, also known as an entitlement, through [IBM Passport Advantage](https://www.ibm.com/software/passportadvantage/index.html).

# Installing

For installation instructions, see  https://cloud.ibm.com/docs/cloud-pak-security. The installation takes approximately 1.5 hours to complete.

## Configuration

The following table lists the configurable parameters for Cloud Pak® for Security and their default values.

| Required Values | Description | Default 
| --------- | ----------- | ----------- |
| adminUser | The Admin user who will be given administrative privileges in the default account. |  |

| Optional Values  | Description | Default
| --------- | ----------- | ----------- |
| domain | The Fully Qualified Domain Name (FQDN) created for Cloud Pak for Security. When the domain is not specified, it will be generated as `cp4s.<cluster_ingress_subdomain>`. |  |
| domainCertificate | TLS certificate associated to the IBM Cloud Pak&reg; for Security application domain. If the `domain` is not specified, OpenShift cluster certificates will be used. For more information, see [TLS certificate](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/security-pak/tls_certs.html). |  |
| domainCertificateKey | TLS key associated to the IBM Cloud Pak&reg; for Security application domain. If the `domain` is not specified, OpenShift cluster certificates will be used. For more information, see [TLS certificate](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/security-pak/tls_certs.html). |  |
| customCA | Custom TLS certificate associated to the IBM Cloud Pak&reg; for Security application domain. If the `domain` is not specified, OpenShift cluster certificates will be used. For more information, see [TLS certificate](https://www.ibm.com/docs/en/SSTDPP_1.10/docs/security-pak/tls_certs.html). |  |
| storageClass | The provisioned block or file storage class to be used for creating all the PVCs required by IBM Cloud Pak&reg; for Security. When it is not specified, the default storage class in the cluster will be used. |  |
| backupStorageClass | Storage class used for creating the backup PVC. If this value is not set, IBM Cloud Pak&reg; for Security will use the same value set in `storageClass` parameter. |  |
| backupStorageSize | Override the default backup storage PVC size. | 500Gi |
| imagePullPolicy | Image pull policy for the containers. | IfNotPresent |
| roksAuthentication | Enable ROKS Authentication. For more details, see https://www.ibm.com/docs/en/cpfs?topic=types-delegating-authentication-openshift. | false |
| deployDRC | Deploy Detection and Response Center (Beta) application. Optional when deploying Cloud Pak for Security. See more details in (https://www.ibm.com/docs/en/SSTDPP_1.10/docs/drc/c_DRC_intro.html). | true |
| deployRiskManager | Deploy Risk Manager application. Optional when deploying Cloud Pak for Security. See more details in (https://www.ibm.com/docs/en/SSTDPP_1.10/datariskmanager/welcome.html). | true |
| deployThreatInvestigator | Deploy Threat Investigator application. Optional when deploying Cloud Pak for Security. See more details in (https://www.ibm.com/docs/en/SSTDPP_1.10/investigator/investigator_intro.html). | true |

# Documentation
Documentation for IBM Cloud Pak&reg; for Security can be found at https://www.ibm.com/docs/en/cloud-paks/cp-security/1.10.

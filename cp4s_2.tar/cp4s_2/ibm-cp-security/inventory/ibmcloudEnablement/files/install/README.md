Before install, please configure all the required deployment values.

After you click **Install**, you are redirected to the workspace to track your installation. After the installation is complete, you can follow the post-install steps as described at https://www.ibm.com/docs/en/SSTDPP_1.10/docs/security-pak/postinstallation.html to setup users to access the Cloudpak for Security via the Fully Qualified Domain Name (FQDN) assigned to the application.

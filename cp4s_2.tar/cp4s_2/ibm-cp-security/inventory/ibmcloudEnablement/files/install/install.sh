#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2021,2022. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************

#===  FUNCTION  ================================================================
#   NAME: error_exit
#   DESCRIPTION:  function to exit with custom error message
#   PARAMETERS:
#       1: message to error to stdout
# ===============================================================================
function error_exit() {
    echo >&2 "[ERROR] $1"
    exit 1
}

#===  FUNCTION  ================================================================
#   NAME: run
#   DESCRIPTION:  run a command to check for errors and exit if failed
#   PARAMETERS:
#       1: command to be executed
#       2: operation being executed, to aid error log output
# ===============================================================================
function run(){
  local cmd=$1
  local operation=$2
  if ! bash $cmd; then
    error_exit "$operation failed"
  fi

}

#===  FUNCTION  ================================================================
#   NAME: convert_cert
#   DESCRIPTION:  convert cert to file
#   PARAMETERS:
#       1: file_name
#       2: file_data
# ===============================================================================
function convert_cert(){
    file_name="$1"
    file_data="$2"
    printf "%s" "${file_data}" > ${file_name}
    sed -i 's/\\n/\n/g' ${file_name}
    sed -i 's/\"//g' ${file_name}
}

#===  FUNCTION  ================================================================
#   NAME: process_certs
#   DESCRIPTION:  process_certs
#   PARAMETERS:
# ===============================================================================
function process_certs(){
    if [ ! -z "${domain}" ]; then
        convert_cert "./cert.crt" "${cert_file}"
        convert_cert "./cert.key" "${key_file}" 
        
        # get the absolute paths to these cert and key files
        cert_file_path=$(ls -d "$PWD"/cert.crt)
        key_file_path=$(ls -d "$PWD"/cert.key)
        
        if [ ! -z "${custom_ca}" ]; then
            convert_cert "./ca.crt" "${custom_ca}"
            custom_ca_path=$(ls -d "$PWD"/ca.crt)
        fi
    fi
        
}

function updateValues() {
    # get the paths to cert and key files
    process_certs

    # write to values.conf
    UPDATED_VALUES="adminUser=\"${default_admin_user}\"\nairgapInstall=\"false\"\ndomain=\"${domain}\"\ndomainCertificatePath=\"${cert_file_path}\"\ndomainCertificateKeyPath=\"${key_file_path}\"\ncustomCaFilePath=\"${custom_ca_path}\"\nentitledKey=\"${entitledKey}\"\nstorageClass=\"${storageclass}\"\nbackupStorageClass=\"${backupStorageClass}\"\nbackupStorageSize=\"${backupStorageSize}\"\nimagePullPolicy=\"${pullPolicy}\"\nrepository=\"${REPOSITORY}\"\nrepositoryUsername=\"${DOCKER_REGISTRY_USER}\"\nrepositoryPassword=\"${DOCKER_REGISTRY_PASS}\"\nroksAuthentication=\"${roksAuthentication}\"\ndeployDRC=\"${deployDRC}\"\ndeployRiskManager=\"${deployRiskManager}\"\ndeployThreatInvestigator=\"${deployThreatInvestigator}\""
    
    printf "${UPDATED_VALUES}" > ./ibm-cp-security/inventory/ibmSecurityOperatorSetup/files/values.conf
  
}


#===  FUNCTION  ================================================================
#   NAME: install
#   DESCRIPTION:  cp4s install orchestrator function
# ===============================================================================
function install() {
    if [[ ${REPOSITORY} != *"cp.icr.io"* ]]; then
        if ! cloudctl case launch -t 1 --case ibm-cp-security --namespace "$NAMESPACE" --inventory ibmSecurityOperatorSetup --action install --args "--acceptLicense true --dev --registry cp.icr.io --user cp --pass ${entitledKey} --skipCredsValidation ${channel} ${catalog}"; then
            error_exit "CP4S Installation Failed."
        fi
    else
        if ! cloudctl case launch -t 1 --case ibm-cp-security --namespace "$NAMESPACE" --inventory ibmSecurityOperatorSetup --action install --args "--acceptLicense true --skipCredsValidation"; then
            error_exit "CP4S Installation Failed."
        fi
    fi
}

#===  CONSTANTS  ================================================================
NAMESPACE=${JOB_NAMESPACE}

REPOSITORY=${repository}
if [[ -z "${REPOSITORY}" ]]; then
    REPOSITORY="cp.icr.io/cp/cp4s"
    if [[ -z "${DOCKER_REGISTRY_PASS}" ]]; then
        error_exit "Entitlement license not found"
    else
        DOCKER_REGISTRY_USER=${DOCKER_REGISTRY_USER:-ekey}
        DOCKER_REGISTRY_PASS=${DOCKER_REGISTRY_PASS}
    fi
else
    DOCKER_REGISTRY_USER=${repositoryUsername}
    DOCKER_REGISTRY_PASS=${repositoryPassword}
fi

# TODO - CAN BE REMOVED BEFORE PROMOTION
if [[ -n "${channelName}" ]]; then
    channel="--channelName ${channelName}"
fi
if [[ -n "${catalogSrcTag}" ]]; then
    catalog="--catalogSrcTag ${catalogSrcTag}"
fi
entitledKey=${entitledKey}
# END OF TODO

export base_dir="$(cd $(dirname $0) && pwd)" # /ibm-cp-security/inventory/ibmcloudEnablement/files/install
casepath="${base_dir}/../../../.."
export casePath="$(dirname -- $(dirname -- $(dirname -- $(dirname -- $base_dir))))"
# If ROKS is set then parameters cert_file/key_file/custom_ca and domain are optional
roksAuthentication=${roksAuthentication}
domain=${domain}
storageclass=${storageClass}
cert_file=${domainCertificate}
cert_file_path=""
key_file=${domainCertificateKey}
key_file_path=""
custom_ca=${customCa}
custom_ca_path=""
default_admin_user=${adminUser}
backupStorageClass=${backupStorageClass}
backupStorageSize=${backupStorageSize}
pullPolicy=${imagePullPolicy}
export kubernetesCLI="oc"
export namespace="${NAMESPACE}" #required in installRedisCouch

# ====== MAIN ==========================
run "$base_dir/validation.sh" "catalog install validation" # performs the validation prior to any action
updateValues
install

#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2021. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************

export base_dir="$(cd $(dirname $0) && pwd)" 
export namespace=${JOB_NAMESPACE}
export cs_namespace="ibm-common-services"
export kubernetesCLI='oc'

#===  FUNCTION  ================================================================
#   NAME: error_exit
#   DESCRIPTION:  function to exit with custom error message
#   PARAMETERS:
#       1: message to error to stdout
# ===============================================================================
error_exit() {
    echo >&2 "[ERROR] $1"
    exit 1
}

uninstall() {

  if ! cloudctl case launch -t 1 --case ibm-cp-security --namespace "$namespace"  --inventory ibmSecurityOperatorSetup --action uninstall --args "--deleteCr threatmgmt  --debug"; then
    error_exit "Failed to uninstall CP4S Threat Management CR"
  fi

}

# ====== MAIN ==========================
uninstall

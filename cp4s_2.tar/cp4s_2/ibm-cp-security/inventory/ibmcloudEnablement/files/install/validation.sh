#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2021. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************

#===  CONSTANTS  ================================================================

export check=0
domain=${domain}
storageclass="${storageClass}"
cert_file="${domainCertificate}"
key_file="${domainCertificateKey}"
admin="${adminUser}"

# validating adminUser
if [ -z "${admin}" ]; then
    echo "[ERROR] CP4S default admin user must be set"
    check=1
fi

# validating the domain
if [[ -n "${domain}" ]]; then
  if ! [[ ${domain} =~ ^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9])(.([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]))*$ ]]; then
    echo "[ERROR] the provided CP4S FQDN is invalid"
    check=1
  fi
  # validating certificates if the domain passed in doesn't match the automatically generated domain
  generated_domain="cp4s.$(oc get -n openshift-console route console -o jsonpath="{.spec.host}" | sed -e 's/^[^\.]*\.//')"
  if [[ $generated_domain != "$domain" ]]; then
      if [[ -z "${cert_file}" ]] || [[ -z "${key_file}" ]]; then
          echo "[ERROR] certificate and certificate key must be provided"
          check=1
      fi
  fi
fi

if [ $check -ne 0 ]; then
  exit 1
fi
